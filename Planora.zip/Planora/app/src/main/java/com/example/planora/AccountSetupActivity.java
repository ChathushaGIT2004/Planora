package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccountSetupActivity extends AppCompatActivity {
    private RadioGroup rgUserType;
    private Button btnContinue;
    private int userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_account_setup);

        // Get user information from intent
        userId = getIntent().getIntExtra("user_id", -1);


        if (userId == -1 ) {
            Toast.makeText(this, "Error: User information not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        rgUserType = findViewById(R.id.rgUserType);
        btnContinue = findViewById(R.id.btnContinue);

        // Set click listener for continue button
        btnContinue.setOnClickListener(v -> handleContinue());
    }

    private void handleContinue() {
        int selectedId = rgUserType.getCheckedRadioButtonId();
        
        if (selectedId == -1) {
            Toast.makeText(this, "Please select your role", Toast.LENGTH_SHORT).show();
            return;
        }

        String userType;
        if (selectedId == R.id.rbClient) {
            userType = "Client";
        } else if (selectedId == R.id.rbVendor) {
            userType = "Vendor";
        } else {
            userType = "";
        }

        // Update user role in database
        StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.8.199/planora/update_role.php",
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            // Navigate to appropriate activity based on user type
                            Intent intent;
                            if (userType=="Client") {

                                intent = new Intent(this, Client_AccountSetup1_Activity.class);
                                intent.putExtra("user_id", userId);
                                startActivity(intent);
                                finish();
                            } else {
                               /* intent = new Intent(this, Vendor_AccountSetup1_Activity.class);
                                intent.putExtra("user_id", userId);
                                startActivity(intent);
                                finish();*/
                            }
                            // Pass user information to the next activity

                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error processing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.toString(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                params.put("role", userType);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
} 