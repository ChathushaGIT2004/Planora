package com.example.planora;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import com.example.planora.adapters.BudgetAdapter;
import com.example.planora.models.BudgetItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
/*
public class BudgetTrackerFragment extends Fragment {
    private TextView totalBudgetText;
    private TextView remainingBudgetText;
    private TextView venueAmountText;
    private TextView cateringAmountText;
    private TextView photographyAmountText;
    private TextView decorAmountText;
    private ProgressBar venueProgress;
    private ProgressBar cateringProgress;
    private ProgressBar photographyProgress;
    private ProgressBar decorProgress;
    private MaterialButton addBudgetButton;
    private MaterialButton addExpenseButton;
    private RecyclerView budgetRecyclerView;
    private BudgetAdapter budgetAdapter;
    private List<BudgetItem> budgetItems;

    private double totalBudget = 10000.0;
    private double remainingBudget = 10000.0;
    private double venueBudget = 0.0;
    private double cateringBudget = 0.0;
    private double photographyBudget = 0.0;
    private double decorBudget = 0.0;

    private NumberFormat currencyFormat;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_budget_tracker, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        initializeViews(view);
        setupRecyclerView();
        loadBudgetData();
        setupClickListeners();
    }

    private void initializeViews(View view) {
        totalBudgetText = view.findViewById(R.id.totalBudgetText);
        remainingBudgetText = view.findViewById(R.id.remainingBudgetText);
        venueAmountText = view.findViewById(R.id.venueAmountText);
        cateringAmountText = view.findViewById(R.id.cateringAmountText);
        photographyAmountText = view.findViewById(R.id.photographyAmountText);
        decorAmountText = view.findViewById(R.id.decorAmountText);
        venueProgress = view.findViewById(R.id.venueProgress);
        cateringProgress = view.findViewById(R.id.cateringProgress);
        photographyProgress = view.findViewById(R.id.photographyProgress);
        decorProgress = view.findViewById(R.id.decorProgress);
        addBudgetButton = view.findViewById(R.id.addBudgetButton);
        addExpenseButton = view.findViewById(R.id.addExpenseButton);
        budgetRecyclerView = view.findViewById(R.id.budgetRecyclerView);
    }

    private void setupRecyclerView() {
        budgetRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        budgetItems = new ArrayList<>();
        budgetAdapter = new BudgetAdapter(budgetItems);
        budgetRecyclerView.setAdapter(budgetAdapter);
    }

    private void loadBudgetData() {
        // Set total budget
        totalBudgetText.setText(currencyFormat.format(totalBudget));
        remainingBudgetText.setText(currencyFormat.format(remainingBudget));

        // Create sample budget items
        budgetItems.add(new BudgetItem("Venue", currencyFormat.format(venueBudget), "Booked"));
        budgetItems.add(new BudgetItem("Catering", currencyFormat.format(cateringBudget), "Menu Selected"));
        budgetItems.add(new BudgetItem("Photography", currencyFormat.format(photographyBudget), "In Progress"));
        budgetItems.add(new BudgetItem("Decor", currencyFormat.format(decorBudget), "Planning"));

        // Update adapter with new data
        budgetAdapter.updateData(budgetItems);

        // Update budget display
        updateBudgetDisplay();
    }

    private void updateBudgetDisplay() {
        venueAmountText.setText(currencyFormat.format(venueBudget));
        cateringAmountText.setText(currencyFormat.format(cateringBudget));
        photographyAmountText.setText(currencyFormat.format(photographyBudget));
        decorAmountText.setText(currencyFormat.format(decorBudget));

        // Update progress bars (assuming each category has a max of 25% of total budget)
        double maxPerCategory = totalBudget * 0.25;
        venueProgress.setProgress((int) ((venueBudget / maxPerCategory) * 100));
        cateringProgress.setProgress((int) ((cateringBudget / maxPerCategory) * 100));
        photographyProgress.setProgress((int) ((photographyBudget / maxPerCategory) * 100));
        decorProgress.setProgress((int) ((decorBudget / maxPerCategory) * 100));
    }

    private void setupClickListeners() {
        addBudgetButton.setOnClickListener(v -> showAddBudgetDialog());
        addExpenseButton.setOnClickListener(v -> showAddExpenseDialog());
    }

    private void showAddBudgetDialog() {
        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.dialog_add_budget);

        AutoCompleteTextView categoryDropdown = dialog.findViewById(R.id.categoryDropdown);
        TextInputEditText amountInput = dialog.findViewById(R.id.amountInput);
        TextInputEditText descriptionInput = dialog.findViewById(R.id.descriptionInput);
        MaterialButton cancelButton = dialog.findViewById(R.id.cancelButton);
        MaterialButton saveButton = dialog.findViewById(R.id.saveButton);

        // Setup category dropdown
        String[] categories = {"Venue", "Catering", "Photography", "Decor"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, categories);
        categoryDropdown.setAdapter(adapter);

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String category = categoryDropdown.getText().toString();
            String amountStr = amountInput.getText().toString();
            String description = descriptionInput.getText().toString();

            if (category.isEmpty() || amountStr.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double amount = Double.parseDouble(amountStr);
                if (amount > remainingBudget) {
                    Toast.makeText(requireContext(), "Amount exceeds remaining budget", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Update budget based on category
                switch (category) {
                    case "Venue":
                        venueBudget += amount;
                        break;
                    case "Catering":
                        cateringBudget += amount;
                        break;
                    case "Photography":
                        photographyBudget += amount;
                        break;
                    case "Decor":
                        decorBudget += amount;
                        break;
                }

                remainingBudget -= amount;
                updateBudgetDisplay();
                dialog.dismiss();
                Toast.makeText(requireContext(), "Budget item added successfully", Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(requireContext(), "Please enter a valid amount", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void showAddExpenseDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_expense, null);
        TextInputEditText categoryInput = dialogView.findViewById(R.id.categoryInput);
        TextInputEditText amountInput = dialogView.findViewById(R.id.amountInput);
        TextInputEditText statusInput = dialogView.findViewById(R.id.statusInput);

        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add New Expense")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String category = categoryInput.getText().toString();
                    String amount = amountInput.getText().toString();
                    String status = statusInput.getText().toString();

                    if (!category.isEmpty() && !amount.isEmpty() && !status.isEmpty()) {
                        BudgetItem newItem = new BudgetItem(category, "$" + amount, status);
                        budgetItems.add(newItem);
                        budgetAdapter.updateData(budgetItems);
                        updateTotalBudget();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateTotalBudget() {
        // Calculate total spent
        double totalSpent = 0;
        for (BudgetItem item : budgetItems) {
            String amount = item.getAmount().replace("$", "").replace(",", "");
            totalSpent += Double.parseDouble(amount);
        }

        // Update remaining budget
        double totalBudget = 50000; // Example total budget
        double remaining = totalBudget - totalSpent;

        totalBudgetText.setText(String.format("$%,.2f", totalBudget));
        remainingBudgetText.setText(String.format("Remaining: $%,.2f", remaining));
    }
} */