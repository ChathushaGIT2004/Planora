package com.example.planora;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.CircularProgressIndicator;

import com.example.planora.adapters.BudgetAdapter;
import com.example.planora.models.BudgetItem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
/*
public class ClientPlanningFragment extends Fragment {

    private MaterialButton viewTimelineButton;
    private MaterialButton viewTasksButton;
    private MaterialButton viewVendorsButton;
    private MaterialButton viewBudgetButton;
    private MaterialButton viewGuestListButton;
    private ProgressBar overallProgressBar;
    private TextView overallProgressText;
    private ProgressBar venueProgressBar;
    private ProgressBar vendorsProgressBar;
    private ProgressBar invitationsProgressBar;
    private ProgressBar detailsProgressBar;
    private ProgressBar preparationsProgressBar;

    private TextView weddingDateText;
    private TextView countdownText;
    private CircularProgressIndicator totalProgress;
    private TextView totalProgressText;
    private TextView venueStatus;
    private TextView cateringStatus;
    private TextView photographyStatus;
    private TextView decorStatus;

    private RecyclerView budgetRecyclerView;
    private BudgetAdapter budgetAdapter;

    private Handler handler;
    private Runnable countdownRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_client_planning, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initializeViews(view);
        setupClickListeners();
        setupRecyclerView();
        setupCountdown();
        loadBudgetData();
    }

    private void initializeViews(View view) {
        viewTimelineButton = view.findViewById(R.id.viewTimelineButton);
        viewTasksButton = view.findViewById(R.id.viewTasksButton);
        viewVendorsButton = view.findViewById(R.id.viewVendorsButton);
        viewBudgetButton = view.findViewById(R.id.viewBudgetButton);
        viewGuestListButton = view.findViewById(R.id.viewGuestListButton);
        overallProgressBar = view.findViewById(R.id.overallProgressBar);
        overallProgressText = view.findViewById(R.id.overallProgressText);
        venueProgressBar = view.findViewById(R.id.venueProgressBar);
        vendorsProgressBar = view.findViewById(R.id.vendorsProgressBar);
        invitationsProgressBar = view.findViewById(R.id.invitationsProgressBar);
        detailsProgressBar = view.findViewById(R.id.detailsProgressBar);
        preparationsProgressBar = view.findViewById(R.id.preparationsProgressBar);

        weddingDateText = view.findViewById(R.id.weddingDateText);
        countdownText = view.findViewById(R.id.countdownText);
        totalProgress = view.findViewById(R.id.totalProgress);
        totalProgressText = view.findViewById(R.id.totalProgressText);
        venueStatus = view.findViewById(R.id.venueStatus);
        cateringStatus = view.findViewById(R.id.cateringStatus);
        photographyStatus = view.findViewById(R.id.photographyStatus);
        decorStatus = view.findViewById(R.id.decorStatus);

        budgetRecyclerView = view.findViewById(R.id.budgetRecyclerView);
    }

    private void setupClickListeners() {
        viewTimelineButton.setOnClickListener(v -> {
            // TODO: Navigate to timeline fragment
            // Navigation.findNavController(v).navigate(R.id.action_clientPlanningFragment_to_timelineFragment);
        });

        viewTasksButton.setOnClickListener(v -> {
            // TODO: Navigate to tasks fragment
            // Navigation.findNavController(v).navigate(R.id.action_clientPlanningFragment_to_tasksFragment);
        });

        viewVendorsButton.setOnClickListener(v -> {
            // TODO: Navigate to vendors fragment
            // Navigation.findNavController(v).navigate(R.id.action_clientPlanningFragment_to_vendorsFragment);
        });

        viewBudgetButton.setOnClickListener(v -> {
            // TODO: Navigate to budget fragment
            // Navigation.findNavController(v).navigate(R.id.action_clientPlanningFragment_to_budgetFragment);
        });

        viewGuestListButton.setOnClickListener(v -> {
            // TODO: Navigate to guest list fragment
            // Navigation.findNavController(v).navigate(R.id.action_clientPlanningFragment_to_guestListFragment);
        });
    }

    private void setupRecyclerView() {
        budgetRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        budgetAdapter = new BudgetAdapter(new ArrayList<>());
        budgetRecyclerView.setAdapter(budgetAdapter);
    }

    private void setupCountdown() {
        // Set wedding date (example: June 15, 2024)
        Calendar weddingDate = Calendar.getInstance();
        weddingDate.set(2024, Calendar.JUNE, 15);
        Date weddingDateObj = weddingDate.getTime();

        // Format wedding date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.getDefault());
        weddingDateText.setText(dateFormat.format(weddingDateObj));

        // Setup countdown
        handler = new Handler(Looper.getMainLooper());
        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                long weddingTime = weddingDate.getTimeInMillis();
                long timeRemaining = weddingTime - currentTime;

                if (timeRemaining <= 0) {
                    countdownText.setText("Wedding Day!");
                } else {
                    long days = TimeUnit.MILLISECONDS.toDays(timeRemaining);
                    long hours = TimeUnit.MILLISECONDS.toHours(timeRemaining) % 24;
                    long minutes = TimeUnit.MILLISECONDS.toMinutes(timeRemaining) % 60;
                    countdownText.setText(String.format(Locale.getDefault(),
                            "%d days, %d hours, %d minutes remaining", days, hours, minutes));
                }
                handler.postDelayed(this, 60000); // Update every minute
            }
        };
        handler.post(countdownRunnable);
    }

    private void loadBudgetData() {
        // Update total progress
        int totalProgressValue = 65; // Example value
        totalProgress.setProgress(totalProgressValue);
        totalProgressText.setText(totalProgressValue + "% Complete");

        // Create sample budget items
        List<BudgetItem> budgetItems = new ArrayList<>();
        budgetItems.add(new BudgetItem("Venue", "Booked", 100));
        budgetItems.add(new BudgetItem("Catering", "Menu Selected", 75));
        budgetItems.add(new BudgetItem("Photography", "In Progress", 50));
        budgetItems.add(new BudgetItem("Decor", "Planning", 25));

        // Update adapter with new data
        budgetAdapter.updateData(budgetItems);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (handler != null && countdownRunnable != null) {
            handler.removeCallbacks(countdownRunnable);
        }
    }
} */