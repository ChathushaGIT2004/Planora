package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup1_Activity extends AppCompatActivity {
    private EditText etBrideName, etBridePhone, etGroomName, etGroomPhone;
    private Button btnContinue;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup1);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        etBrideName = findViewById(R.id.etBrideName);
        etBridePhone = findViewById(R.id.etBridePhone);
        etGroomName = findViewById(R.id.etGroomName);
        etGroomPhone = findViewById(R.id.etGroomPhone);
        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(v -> handleContinue());
    }

    private void handleContinue() {
        String brideName = etBrideName.getText().toString().trim();
        String bridePhone = etBridePhone.getText().toString().trim();
        String groomName = etGroomName.getText().toString().trim();
        String groomPhone = etGroomPhone.getText().toString().trim();

        if (brideName.isEmpty() || bridePhone.isEmpty() || groomName.isEmpty() || groomPhone.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidPhoneNumber(bridePhone) || !isValidPhoneNumber(groomPhone)) {
            Toast.makeText(this, "Please enter valid phone numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            Intent intent = new Intent(this, Client_AccountSetup2_Activity.class);
                            intent.putExtra("user_id", userId);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("BrideName", brideName);
                params.put("BrideTpNo", bridePhone);
                params.put("GroomName", groomName);
                params.put("GroomTpNo", groomPhone);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private boolean isValidPhoneNumber(String phone) {
        return phone.matches("\\d{10,}");
    }
}
