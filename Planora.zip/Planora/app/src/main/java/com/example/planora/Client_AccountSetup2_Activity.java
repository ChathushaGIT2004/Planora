package com.example.planora;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup2_Activity extends AppCompatActivity {
    private EditText etWeddingDate;
    private Button btnContinue;
    private TextView tvSkip;
    private int userId;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup2);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        etWeddingDate = findViewById(R.id.etWeddingDate);
        btnContinue = findViewById(R.id.btnContinue);
        tvSkip = findViewById(R.id.tvSkip);
        calendar = Calendar.getInstance();

        // Set minimum date to today
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        // Set date picker click listener
        etWeddingDate.setOnClickListener(v -> showDatePicker());

        btnContinue.setOnClickListener(v -> handleContinue());
        tvSkip.setOnClickListener(v -> handleSkip());
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
            this,
            (view, year, month, dayOfMonth) -> {
                String date = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                etWeddingDate.setText(date);
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
        datePickerDialog.show();
    }

    private void handleContinue() {
        String weddingDate = etWeddingDate.getText().toString().trim();

        if (weddingDate.isEmpty()) {
            Toast.makeText(this, "Please select a wedding date", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            navigateToNext();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("WeddingDate", weddingDate);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleSkip() {
        navigateToNext();
    }

    private void navigateToNext() {
        Intent intent = new Intent(this, Client_AccountSetup3_Activity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
        finish();
    }
} 