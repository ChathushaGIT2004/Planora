package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup3_Activity extends AppCompatActivity {
    private EditText etBudget;
    private Button btnContinue;
    private TextView tvSkip;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup3);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        etBudget = findViewById(R.id.etBudget);
        btnContinue = findViewById(R.id.btnContinue);
        tvSkip = findViewById(R.id.tvSkip);

        btnContinue.setOnClickListener(v -> handleContinue());
        tvSkip.setOnClickListener(v -> handleSkip());
    }

    private void handleContinue() {
        String budget = etBudget.getText().toString().trim();
        
        if (TextUtils.isEmpty(budget)) {
            etBudget.setError("Please enter your budget");
            return;
        }

        try {
            double budgetAmount = Double.parseDouble(budget);
            if (budgetAmount <= 0) {
                etBudget.setError("Budget must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            etBudget.setError("Please enter a valid amount");
            return;
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            navigateToNext();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("Budget", budget);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleSkip() {
        navigateToNext();
    }

    private void navigateToNext() {
        Intent intent = new Intent(this, Client_AccountSetup4_Activity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
        finish();
    }
} 