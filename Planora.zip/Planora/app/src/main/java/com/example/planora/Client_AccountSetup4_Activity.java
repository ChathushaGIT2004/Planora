package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup4_Activity extends AppCompatActivity {
    private EditText etGuestCount;
    private Spinner spinnerDistrict;
    private Spinner spinnerCity;
    private Button btnContinue;
    private TextView tvSkip;
    private int userId;
    private Map<String, String[]> districtCities;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup4);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        etGuestCount = findViewById(R.id.etGuestCount);
        spinnerDistrict = findViewById(R.id.spinnerDistrict);
        spinnerCity = findViewById(R.id.spinnerCity);
        btnContinue = findViewById(R.id.btnContinue);
        tvSkip = findViewById(R.id.tvSkip);

        // Initialize district-cities map
        initializeDistrictCities();

        // Set up district spinner
        String[] districts = districtCities.keySet().toArray(new String[0]);
        ArrayAdapter<String> districtAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, districts);
        districtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDistrict.setAdapter(districtAdapter);

        // Set up district selection listener
        spinnerDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedDistrict = districts[position];
                String[] cities = districtCities.get(selectedDistrict);
                ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(Client_AccountSetup4_Activity.this,
                        android.R.layout.simple_spinner_item, cities);
                cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCity.setAdapter(cityAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        btnContinue.setOnClickListener(v -> handleContinue());
        tvSkip.setOnClickListener(v -> handleSkip());
    }

    private void initializeDistrictCities() {
        districtCities = new HashMap<>();
        
        // Add districts and their major cities
        districtCities.put("Colombo", new String[]{"Colombo", "Dehiwala", "Moratuwa", "Mount Lavinia"});
        districtCities.put("Gampaha", new String[]{"Negombo", "Gampaha", "Ja-Ela", "Wattala"});
        districtCities.put("Kalutara", new String[]{"Kalutara", "Panadura", "Horana", "Bandaragama"});
        districtCities.put("Kandy", new String[]{"Kandy", "Peradeniya", "Katugastota", "Gampola"});
        districtCities.put("Matale", new String[]{"Matale", "Dambulla", "Galewela"});
        districtCities.put("Nuwara Eliya", new String[]{"Nuwara Eliya", "Hatton", "Talawakele"});
        districtCities.put("Galle", new String[]{"Galle", "Ambalangoda", "Hikkaduwa"});
        districtCities.put("Matara", new String[]{"Matara", "Weligama", "Dikwella"});
        districtCities.put("Hambantota", new String[]{"Hambantota", "Tangalle", "Tissamaharama"});
        districtCities.put("Jaffna", new String[]{"Jaffna", "Chavakachcheri", "Point Pedro"});
        districtCities.put("Kilinochchi", new String[]{"Kilinochchi", "Pallai"});
        districtCities.put("Mannar", new String[]{"Mannar", "Madhu"});
        districtCities.put("Vavuniya", new String[]{"Vavuniya", "Omanthai"});
        districtCities.put("Mullaitivu", new String[]{"Mullaitivu", "Puthukkudiyiruppu"});
        districtCities.put("Batticaloa", new String[]{"Batticaloa", "Kattankudy", "Eravur"});
        districtCities.put("Ampara", new String[]{"Ampara", "Kalmunai", "Dehiattakandiya"});
        districtCities.put("Trincomalee", new String[]{"Trincomalee", "Kantale", "Muttur"});
        districtCities.put("Kurunegala", new String[]{"Kurunegala", "Kuliyapitiya", "Polgahawela"});
        districtCities.put("Puttalam", new String[]{"Puttalam", "Chilaw", "Wennappuwa"});
        districtCities.put("Anuradhapura", new String[]{"Anuradhapura", "Medawachchiya", "Tambuttegama"});
        districtCities.put("Polonnaruwa", new String[]{"Polonnaruwa", "Kaduruwela", "Hingurakgoda"});
        districtCities.put("Badulla", new String[]{"Badulla", "Bandarawela", "Haputale"});
        districtCities.put("Monaragala", new String[]{"Monaragala", "Bibile", "Wellawaya"});
        districtCities.put("Ratnapura", new String[]{"Ratnapura", "Embilipitiya", "Balangoda"});
        districtCities.put("Kegalle", new String[]{"Kegalle", "Mawanella", "Warakapola"});
    }

    private void handleContinue() {
        String guestCount = etGuestCount.getText().toString().trim();
        String district = spinnerDistrict.getSelectedItem().toString();
        String city = spinnerCity.getSelectedItem().toString();

        if (TextUtils.isEmpty(guestCount)) {
            etGuestCount.setError("Please enter guest count");
            return;
        }

        try {
            int count = Integer.parseInt(guestCount);
            if (count <= 0) {
                etGuestCount.setError("Guest count must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            etGuestCount.setError("Please enter a valid number");
            return;
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            navigateToNext();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("GuestCount", guestCount);
                params.put("District", district);
                params.put("City", city);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleSkip() {
        navigateToNext();
    }

    private void navigateToNext() {
        Intent intent = new Intent(this, Client_AccountSetup5_Activity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
        finish();
    }
} 