package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup5_Activity extends AppCompatActivity {
    private RadioGroup rgVenueType;
    private Button btnContinue;
    private TextView tvSkip;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup5);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        rgVenueType = findViewById(R.id.rgVenueType);
        btnContinue = findViewById(R.id.btnContinue);
        tvSkip = findViewById(R.id.tvSkip);

        btnContinue.setOnClickListener(v -> handleContinue());
        tvSkip.setOnClickListener(v -> handleSkip());
    }

    private void handleContinue() {
        int selectedId = rgVenueType.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Please select a venue type", Toast.LENGTH_SHORT).show();
            return;
        }

        String venueType = "";
        if (selectedId == R.id.rbIndoor) {
            venueType = "Indoor";
        } else if (selectedId == R.id.rbOutdoor) {
            venueType = "Outdoor";
        } else if (selectedId == R.id.rbBoth) {
            venueType = "Both";
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        String finalVenueType = venueType;
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            navigateToNext();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("VenueType", finalVenueType);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleSkip() {
        navigateToNext();
    }

    private void navigateToNext() {
        Intent intent = new Intent(this, Client_AccountSetup6_Activity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
        finish();
    }
} 