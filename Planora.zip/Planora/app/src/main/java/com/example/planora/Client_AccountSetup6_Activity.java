package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Client_AccountSetup6_Activity extends AppCompatActivity {
    private RadioGroup rgCeremonyType;
    private Button btnContinue;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_account_setup6);

        // Receive user ID from intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI elements
        rgCeremonyType = findViewById(R.id.rgCeremonyType);
        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(v -> handleContinue());
    }

    private void handleContinue() {
        int selectedId = rgCeremonyType.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Please select a ceremony type", Toast.LENGTH_SHORT).show();
            return;
        }

        String ceremonyType = "";
        if (selectedId == R.id.rbCivil) {
            ceremonyType = "civil";
        } else if (selectedId == R.id.rbSinhala) {
            ceremonyType = "sinhala";
        } else if (selectedId == R.id.rbTamil) {
            ceremonyType = "tamil";
        } else if (selectedId == R.id.rbChristian) {
            ceremonyType = "christian";
        } else if (selectedId == R.id.rbMuslim) {
            ceremonyType = "muslim";
        }

        // Send data to PHP server
        String url = "http://192.168.8.199/planora/update_couple_info.php";

        String finalCeremonyType = ceremonyType;
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            // Navigate to main activity or dashboard
                            navigateToNext();
                        } else {
                            Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Invalid response from server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", String.valueOf(userId));
                params.put("CeremonyType", finalCeremonyType);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void navigateToNext() {
        Intent intent = new Intent(this, Client_AccountSetup7_Activity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
        finish();
    }
} 