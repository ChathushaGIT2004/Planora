package com.example.planora;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeFragment extends Fragment {
    private EditText searchEditText;
    private RecyclerView featuredVendorsRecyclerView;
    private RecyclerView popularVendorsRecyclerView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize views
        searchEditText = view.findViewById(R.id.searchEditText);
        featuredVendorsRecyclerView = view.findViewById(R.id.featuredVendorsRecyclerView);
        popularVendorsRecyclerView = view.findViewById(R.id.popularVendorsRecyclerView);

        // Setup RecyclerViews
        setupRecyclerViews();

        // Setup search functionality
        setupSearch();
    }

    private void setupRecyclerViews() {
        // Setup Featured Vendors RecyclerView
        featuredVendorsRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        // TODO: Set adapter for featured vendors
        // featuredVendorsRecyclerView.setAdapter(new VendorAdapter(getFeaturedVendors()));

        // Setup Popular Vendors RecyclerView
        popularVendorsRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        // TODO: Set adapter for popular vendors
        // popularVendorsRecyclerView.setAdapter(new VendorAdapter(getPopularVendors()));
    }

    private void setupSearch() {
        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            String searchQuery = searchEditText.getText().toString().trim();
            if (!searchQuery.isEmpty()) {
                // TODO: Implement search functionality
                Toast.makeText(getContext(), "Searching for: " + searchQuery, Toast.LENGTH_SHORT).show();
            }
            return true;
        });
    }
} 