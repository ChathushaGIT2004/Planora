package com.example.planora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import androidx.activity.EdgeToEdge;

public class SignUpActivity extends AppCompatActivity {

    private EditText etEmail, etPassword, etConfirmPassword, etName, etPhone, etBrideName, etGroomName;
    private TextView tvResult;
    private Button btnCreateAccount;
    private LinearLayout btnGoogleSignUp, btnFacebookSignUp;
    private RadioGroup rgRole;

    private static final String REGISTER_URL = "https://yourdomain.com/register.php"; // Change this

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);


        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);

        tvResult = findViewById(R.id.Result);

        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        btnGoogleSignUp = findViewById(R.id.btnGoogleSignUp);
        btnFacebookSignUp = findViewById(R.id.btnFacebookSignUp);

        btnCreateAccount.setOnClickListener(v -> handleCreateAccount());
        btnGoogleSignUp.setOnClickListener(v -> handleGoogleSignUp());
        btnFacebookSignUp.setOnClickListener(v -> handleFacebookSignUp());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void handleCreateAccount() {

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String Cpassword = etConfirmPassword.getText().toString().trim();


        if ( email.isEmpty() || password.isEmpty() || Cpassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 8) {
            tvResult.setText("Password must be at least 8 characters");
            return;
        }

        int symbolCount = 0, numCount = 0;
        for (char c : password.toCharArray()) {
            if ("!@#$".indexOf(c) != -1) symbolCount++;
            if (Character.isDigit(c)) numCount++;
        }

        if (numCount < 2) {
            tvResult.setText("Password must contain at least 2 numbers");
            return;
        }

        if (symbolCount < 1) {
            tvResult.setText("Password must contain at least 1 symbol");
            return;
        }

        if (!password.equals(Cpassword)) {
            tvResult.setText("Passwords do not match");
            return;
        }

        // Send data to PHP
        StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.8.199/planora/signup.php",
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getBoolean("success")) {
                            int userId = json.getInt("user_id");

                            // Navigate to Account Setup with just the user ID
                            Intent intent = new Intent(SignUpActivity.this, AccountSetupActivity.class);
                            intent.putExtra("user_id", userId);
                            startActivity(intent);
                            finish();
                        } else {
                            tvResult.setText(json.getString("message"));
                        }
                    } catch (JSONException e) {
                        tvResult.setText("Invalid response from server");
                        e.printStackTrace(); // Optional for debugging
                    }
                }
                ,
                error -> tvResult.setText("Network error: " + error.toString())
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleGoogleSignUp() {
        // TODO: Implement Google Sign-Up
        Toast.makeText(this, "Google signup clicked", Toast.LENGTH_SHORT).show();
    }

    private void handleFacebookSignUp() {
        // TODO: Implement Facebook Sign-Up
        Toast.makeText(this, "Facebook signup clicked", Toast.LENGTH_SHORT).show();
    }
}


