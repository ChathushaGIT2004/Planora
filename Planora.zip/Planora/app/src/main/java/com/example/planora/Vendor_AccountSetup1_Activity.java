package com.example.planora;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Vendor_AccountSetup1_Activity extends AppCompatActivity {
    private ImageButton backButton;
    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_vendors);

        // Initialize views
        backButton = findViewById(R.id.backButton);
        searchEditText = findViewById(R.id.searchEditText);

        // Set click listeners
        backButton.setOnClickListener(v -> handleBack());
        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            handleSearch();
            return true;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void handleBack() {
        // Navigate back to previous activity
        finish();
    }

    private void handleSearch() {
        String searchQuery = searchEditText.getText().toString().trim();
        if (!searchQuery.isEmpty()) {
            // TODO: Implement search functionality
            Toast.makeText(this, "Searching for: " + searchQuery, Toast.LENGTH_SHORT).show();
        }
    }
}