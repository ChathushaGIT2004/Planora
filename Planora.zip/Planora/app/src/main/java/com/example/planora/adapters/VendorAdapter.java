package com.example.planora.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.planora.R;
import com.example.planora.models.Vendor;

import java.util.List;

public class VendorAdapter extends RecyclerView.Adapter<VendorAdapter.VendorViewHolder> {

    private List<Vendor> vendors;
    private Context context;
    private OnVendorClickListener listener;

    public interface OnVendorClickListener {
        void onVendorClick(Vendor vendor);
    }

    public VendorAdapter(Context context, List<Vendor> vendors, OnVendorClickListener listener) {
        this.context = context;
        this.vendors = vendors;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VendorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_vendor, parent, false);
        return new VendorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VendorViewHolder holder, int position) {
        Vendor vendor = vendors.get(position);
        holder.bind(vendor);
    }

    @Override
    public int getItemCount() {
        return vendors.size();
    }

    public void updateVendors(List<Vendor> newVendors) {
        this.vendors = newVendors;
        notifyDataSetChanged();
    }

    class VendorViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivVendor;
        private TextView tvName;
        private TextView tvCategory;
        private RatingBar ratingBar;
        private TextView tvDescription;
        private TextView tvLocation;

        public VendorViewHolder(@NonNull View itemView) {
            super(itemView);
            ivVendor = itemView.findViewById(R.id.ivVendor);
            tvName = itemView.findViewById(R.id.tvName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvLocation = itemView.findViewById(R.id.tvLocation);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    listener.onVendorClick(vendors.get(position));
                }
            });
        }

        public void bind(Vendor vendor) {
            tvName.setText(vendor.getName());
            tvCategory.setText(vendor.getCategory());
            ratingBar.setRating(vendor.getRating());
            tvDescription.setText(vendor.getDescription());
            tvLocation.setText(vendor.getLocation());

            // Load vendor image using Glide
            Glide.with(context)
                .load(vendor.getImageUrl())
                .placeholder(R.drawable.placeholder_vendor)
                .error(R.drawable.placeholder_vendor)
                .into(ivVendor);
        }
    }
} 