package com.example.planora.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "PlanoraDB";
    private static final int DATABASE_VERSION = 1;

    // Table name
    private static final String TABLE_USERS = "users";

    // Column names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_ROLE = "role";
    private static final String COLUMN_CREATED_AT = "created_at";
    private static final String COLUMN_BRIDE_NAME = "bride_name";
    private static final String COLUMN_GROOM_NAME = "groom_name";
    private static final String COLUMN_IS_BRIDE_LOGGED_IN = "is_bride_logged_in";
    private static final String COLUMN_IS_GROOM_LOGGED_IN = "is_groom_logged_in";
    private static final String COLUMN_LAST_LOGIN = "last_login";

    // Create table query
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_EMAIL + " TEXT UNIQUE,"
            + COLUMN_PASSWORD + " TEXT,"
            + COLUMN_PHONE + " TEXT,"
            + COLUMN_ROLE + " TEXT,"
            + COLUMN_BRIDE_NAME + " TEXT,"
            + COLUMN_GROOM_NAME + " TEXT,"
            + COLUMN_IS_BRIDE_LOGGED_IN + " INTEGER DEFAULT 0,"
            + COLUMN_IS_GROOM_LOGGED_IN + " INTEGER DEFAULT 0,"
            + COLUMN_LAST_LOGIN + " DATETIME,"
            + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Add new user
    public long addUser(String name, String email, String password, String phone, String role, 
                       String brideName, String groomName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_ROLE, role);
        values.put(COLUMN_BRIDE_NAME, brideName);
        values.put(COLUMN_GROOM_NAME, groomName);
        values.put(COLUMN_IS_BRIDE_LOGGED_IN, 0);
        values.put(COLUMN_IS_GROOM_LOGGED_IN, 0);

        long userId = db.insert(TABLE_USERS, null, values);
        db.close();
        return userId;
    }

    // Check if email exists
    public boolean isEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_EMAIL},
                COLUMN_EMAIL + "=?",
                new String[]{email},
                null, null, null);
        
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Verify user login and update login status
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_ROLE},
                COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{email, password},
                null, null, null);
        
        if (cursor.moveToFirst()) {
            String role = cursor.getString(cursor.getColumnIndex(COLUMN_ROLE));
            ContentValues values = new ContentValues();
            
            // Update login status based on role
            if (role.equalsIgnoreCase("bride")) {
                values.put(COLUMN_IS_BRIDE_LOGGED_IN, 1);
            } else if (role.equalsIgnoreCase("groom")) {
                values.put(COLUMN_IS_GROOM_LOGGED_IN, 1);
            }
            
            values.put(COLUMN_LAST_LOGIN, "CURRENT_TIMESTAMP");
            
            db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
            cursor.close();
            db.close();
            return true;
        }
        
        cursor.close();
        db.close();
        return false;
    }

    // Logout user
    public void logoutUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        // Reset both login statuses
        values.put(COLUMN_IS_BRIDE_LOGGED_IN, 0);
        values.put(COLUMN_IS_GROOM_LOGGED_IN, 0);
        
        db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
        db.close();
    }

    // Get user details
    public User getUserDetails(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                null,
                COLUMN_EMAIL + "=?",
                new String[]{email},
                null, null, null);

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User(
                cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_EMAIL)),
                cursor.getString(cursor.getColumnIndex(COLUMN_PHONE)),
                cursor.getString(cursor.getColumnIndex(COLUMN_ROLE)),
                cursor.getString(cursor.getColumnIndex(COLUMN_BRIDE_NAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_GROOM_NAME)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_IS_BRIDE_LOGGED_IN)) == 1,
                cursor.getInt(cursor.getColumnIndex(COLUMN_IS_GROOM_LOGGED_IN)) == 1,
                cursor.getString(cursor.getColumnIndex(COLUMN_LAST_LOGIN)),
                cursor.getString(cursor.getColumnIndex(COLUMN_CREATED_AT))
            );
        }
        cursor.close();
        db.close();
        return user;
    }

    // Check if bride is logged in
    public boolean isBrideLoggedIn() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_IS_BRIDE_LOGGED_IN},
                COLUMN_IS_BRIDE_LOGGED_IN + "=?",
                new String[]{"1"},
                null, null, null);
        
        boolean isLoggedIn = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return isLoggedIn;
    }

    // Check if groom is logged in
    public boolean isGroomLoggedIn() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_IS_GROOM_LOGGED_IN},
                COLUMN_IS_GROOM_LOGGED_IN + "=?",
                new String[]{"1"},
                null, null, null);
        
        boolean isLoggedIn = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return isLoggedIn;
    }

    // Update user role
    public boolean updateUserRole(String email, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ROLE, role);
        
        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
        db.close();
        return rowsAffected > 0;
    }

    // User model class
    public static class User {
        private int userId;
        private String name;
        private String email;
        private String phone;
        private String role;
        private String brideName;
        private String groomName;
        private boolean isBrideLoggedIn;
        private boolean isGroomLoggedIn;
        private String lastLogin;
        private String createdAt;

        public User(int userId, String name, String email, String phone, String role,
                   String brideName, String groomName, boolean isBrideLoggedIn,
                   boolean isGroomLoggedIn, String lastLogin, String createdAt) {
            this.userId = userId;
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.role = role;
            this.brideName = brideName;
            this.groomName = groomName;
            this.isBrideLoggedIn = isBrideLoggedIn;
            this.isGroomLoggedIn = isGroomLoggedIn;
            this.lastLogin = lastLogin;
            this.createdAt = createdAt;
        }

        // Getters
        public int getUserId() { return userId; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getPhone() { return phone; }
        public String getRole() { return role; }
        public String getBrideName() { return brideName; }
        public String getGroomName() { return groomName; }
        public boolean isBrideLoggedIn() { return isBrideLoggedIn; }
        public boolean isGroomLoggedIn() { return isGroomLoggedIn; }
        public String getLastLogin() { return lastLogin; }
        public String getCreatedAt() { return createdAt; }
    }
} 