package com.example.planora.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.planora.R;
import com.example.planora.adapters.VendorAdapter;
import com.example.planora.models.Vendor;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ClientVendorsFragment extends Fragment implements VendorAdapter.OnVendorClickListener {

    private RecyclerView recyclerView;
    private VendorAdapter adapter;
    private List<Vendor> vendors;
    private List<Vendor> filteredVendors;
    private RequestQueue requestQueue;
    private MaterialButton filterButton;
    private ChipGroup categoryChipGroup;
    private String selectedCategory = "All";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_client_vendors, container, false);
        
        // Initialize views
        recyclerView = view.findViewById(R.id.productRecyclerView);
        filterButton = view.findViewById(R.id.filterButton);
        categoryChipGroup = view.findViewById(R.id.categoryChipGroup);
        
        // Initialize data
        vendors = new ArrayList<>();
        filteredVendors = new ArrayList<>();
        adapter = new VendorAdapter(requireContext(), filteredVendors, this);
        
        // Setup RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        recyclerView.setAdapter(adapter);
        
        // Setup filter button
        setupFilterButton();
        
        // Setup category chips
        setupCategoryChips();
        
        // Initialize Volley
        requestQueue = Volley.newRequestQueue(requireContext());
        
        // Load vendors
        loadVendors();
        
        return view;
    }

    private void setupFilterButton() {
        filterButton.setOnClickListener(v -> {
            // TODO: Show filter dialog
            Toast.makeText(requireContext(), "Filter functionality coming soon", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupCategoryChips() {
        // Set initial state for "All" chip
        Chip allChip = categoryChipGroup.findViewById(R.id.chipAll);
        if (allChip != null) {
            allChip.setChecked(true);
            allChip.setChipBackgroundColorResource(R.color.button_primary);
            allChip.setTextColor(getResources().getColor(android.R.color.white));
        }

        categoryChipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            Chip selectedChip = group.findViewById(checkedId);
            if (selectedChip != null) {
                // Update selected category
                selectedCategory = selectedChip.getText().toString();
                
                // Update chip appearances
                for (int i = 0; i < group.getChildCount(); i++) {
                    Chip chip = (Chip) group.getChildAt(i);
                    if (chip.getId() == checkedId) {
                        chip.setChipBackgroundColorResource(R.color.button_primary);
                        chip.setTextColor(getResources().getColor(android.R.color.white));
                    } else {
                        chip.setChipBackgroundColorResource(R.color.chip_background);
                        chip.setTextColor(getResources().getColor(R.color.text_primary));
                    }
                }
                
                // Filter vendors
                filterVendors(selectedCategory);
            }
        });
    }

    private void filterVendors(String category) {
        filteredVendors.clear();
        
        for (Vendor vendor : vendors) {
            if (category.equals("All") || vendor.getCategory().equals(category)) {
                filteredVendors.add(vendor);
            }
        }
        
        adapter.notifyDataSetChanged();
    }

    private void loadVendors() {
        String url = "http://192.168.8.199/planora/get_vendors.php";
        
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
            new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    vendors.clear();
                    
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonObject = response.getJSONObject(i);
                            Vendor vendor = new Vendor(
                                jsonObject.getString("id"),

                                jsonObject.getString("name"),
                                jsonObject.getString("category"),
                                jsonObject.getString("description"),
                                jsonObject.getString("location"),
                                jsonObject.getString("image_url"),
                                (float) jsonObject.getDouble("rating")
                            );
                            vendors.add(vendor);
                        }
                        filterVendors(selectedCategory);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(requireContext(), "Error parsing vendor data", Toast.LENGTH_SHORT).show();
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(requireContext(), "Error loading vendors: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        
        requestQueue.add(request);
    }

    @Override
    public void onVendorClick(Vendor vendor) {
        // TODO: Navigate to vendor details
        Toast.makeText(requireContext(), "Selected: " + vendor.getName(), Toast.LENGTH_SHORT).show();
    }
} 