package com.example.planora.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.planora.R;
import com.example.planora.adapters.VendorAdapter;
import com.example.planora.models.Vendor;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class VendorsFragment extends Fragment implements VendorAdapter.OnVendorClickListener {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private VendorAdapter adapter;
    private List<Vendor> vendors;
    private RequestQueue requestQueue;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_vendors, container, false);
        
        recyclerView = view.findViewById(R.id.recyclerView);
        progressBar = view.findViewById(R.id.progressBar);
        
        vendors = new ArrayList<>();
        adapter = new VendorAdapter(requireContext(), vendors, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(adapter);
        
        requestQueue = Volley.newRequestQueue(requireContext());
        
        loadVendors();
        
        return view;
    }

    private void loadVendors() {
        progressBar.setVisibility(View.VISIBLE);
        
        String url = "http://192.168.8.199/planora/get_vendors.php";
        
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
            new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    progressBar.setVisibility(View.GONE);
                    vendors.clear();
                    
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonObject = response.getJSONObject(i);
                            Vendor vendor = new Vendor(
                                jsonObject.getString("id"),
                                jsonObject.getString("name"),
                                jsonObject.getString("category"),
                                jsonObject.getString("description"),
                                jsonObject.getString("location"),
                                jsonObject.getString("image_url"),
                                (float) jsonObject.getDouble("rating")
                            );
                            vendors.add(vendor);
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(requireContext(), "Error parsing vendor data", Toast.LENGTH_SHORT).show();
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(requireContext(), "Error loading vendors: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        
        requestQueue.add(request);
    }

    @Override
    public void onVendorClick(Vendor vendor) {
        // TODO: Navigate to vendor details activity
        Toast.makeText(requireContext(), "Selected: " + vendor.getName(), Toast.LENGTH_SHORT).show();
    }
} 