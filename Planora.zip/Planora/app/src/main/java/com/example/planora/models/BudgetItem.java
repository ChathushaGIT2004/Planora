package com.example.planora.models;

public class BudgetItem {
    private String category;
    private String amount;
    private String status;

    public BudgetItem(String category, String amount, String status) {
        this.category = category;
        this.amount = amount;
        this.status = status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
} 