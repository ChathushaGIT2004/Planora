package com.example.planora.models;

public class Vendor {
    private int id;
    private String name;
    private String category;
    private String description;
    private String imageUrl;
    private double rating;
    private String location;

    public Vendor(int id, String name, String category, String description, String imageUrl, double rating, String location) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
        this.imageUrl = imageUrl;
        this.rating = rating;
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public double getRating() {
        return rating;
    }

    public String getLocation() {
        return location;
    }
} 